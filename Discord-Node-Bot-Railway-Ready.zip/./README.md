# Discord Node Bot

Single runtime path:

- Entry file: `index.cjs`
- Start command: `npm start`

## Setup

1. Copy `.env.example` to `.env` (already done in this repo).
2. Fill in:
   - `DISCORD_TOKEN`
   - `OPENAI_API_KEY` (optional, but needed for moderation checks)
   - `DISCORD_CLIENT_ID` (optional, for dashboard OAuth)
   - `DISCORD_CLIENT_SECRET` (optional, for dashboard OAuth)
   - `DISCORD_REDIRECT_URI` (optional, for dashboard OAuth callback)
3. Run:
   - `npm install`
   - `npm start`

## Replit Quick Deploy

1. Create a Replit Node.js repl and upload this folder.
2. Add Secrets:
   - `DISCORD_TOKEN`
   - `OPENAI_API_KEY`
   - `PORT` = `3000`
3. Run command: `npm install && npm start`
4. Optional OAuth hardening (recommended):
   - Create Discord OAuth app redirect URI:
     - `https://YOUR-REPL-NAME.YOUR-USERNAME.repl.co/oauth/callback`
   - Set Replit secrets:
     - `DISCORD_CLIENT_ID`
     - `DISCORD_CLIENT_SECRET`
     - `DISCORD_REDIRECT_URI`
   - In dashboard, set `dashboardAuth.enabled` to true and save role/user allowlists.

## Keep It Running 24/7

- Start under PM2: `npm run pm2:start`
- Restart bot: `npm run pm2:restart`
- View logs: `npm run pm2:logs`
- Save current PM2 process list: `npm run pm2:save`

PM2 startup is installed on this machine, so the bot is configured to relaunch after reboot.

## Notes

- Dashboard runs on `PORT` from `.env` (default `3000`).
- Health endpoint: `GET /health` (JSON uptime, readiness, counters).
- Dashboard API health endpoint: `GET /api/health`.
- Warnings and incidents are persisted in `bot.db` (SQLite).
- Dashboard now uses Discord OAuth login (`/login` -> `/oauth/callback`).
- Anti-raid controls:
  - Slash command: `/raidmode` (`on`, `off`, `status`)
  - Dashboard toggle in the Anti-Raid card
- Extra slash commands:
  - `/warnings`
  - `/health`
- Incident log and false-positive controls are available in the dashboard UI.
- Old fullstack app files were moved to `legacy/old-fullstack/` to avoid confusion.
