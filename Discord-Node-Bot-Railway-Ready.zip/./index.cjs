
require("dotenv").config();

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const express = require("express");
const http = require("http");
const Database = require("better-sqlite3");
const { Client, GatewayIntentBits, PermissionsBitField, Partials } = require("discord.js");

const OpenAIModule = require("openai");
const OpenAI = OpenAIModule.default || OpenAIModule;

const DEFAULT_CONFIG = {
  bypassUsers: [],
  logUserId: "",
  timeoutDuration: 60000,
  warningLimit: 3,
  dashboardPort: 3000,
  raidMode: false,
  antiRaid: {
    enabled: true,
    burstWindowMs: 10000,
    burstThreshold: 6,
    duplicateWindowMs: 15000,
    duplicateThreshold: 4,
    timeoutDurationMs: 300000,
    joinAgeFilterEnabled: true,
    minJoinAgeMinutes: 10,
    blockLinksForNewJoins: true,
  },
  health: {
    alertsEnabled: true,
    alertCooldownMs: 300000,
    openaiFailureAlertThreshold: 3,
  },
  dashboardAuth: {
    enabled: false,
    guildId: "",
    allowedRoleIds: [],
    allowedUserIds: [],
  },
  falsePositive: {
    allowedUsers: [],
    allowedChannels: [],
    allowedPhrases: [],
  },
};

const CONFIG_PATH = path.join(__dirname, "config.json");
const WARNINGS_PATH = path.join(__dirname, "warnings.json");
const DB_PATH = path.join(__dirname, "bot.db");
const SESSION_COOKIE = "dashboard_sid";
const SESSION_TTL_MS = 1000 * 60 * 60 * 24;

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS warnings (user_id TEXT PRIMARY KEY, count INTEGER NOT NULL DEFAULT 0, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS incidents (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL,
  type TEXT NOT NULL,
  user_id TEXT,
  user_tag TEXT,
  guild_id TEXT,
  guild_name TEXT,
  channel_id TEXT,
  channel_name TEXT,
  reason TEXT,
  content TEXT,
  action TEXT,
  severity TEXT
);
`);

const sql = {
  getWarning: db.prepare("SELECT count FROM warnings WHERE user_id = ?"),
  upsertWarning: db.prepare("INSERT INTO warnings (user_id,count,updated_at) VALUES (?,?,?) ON CONFLICT(user_id) DO UPDATE SET count=excluded.count, updated_at=excluded.updated_at"),
  resetAllWarnings: db.prepare("UPDATE warnings SET count = 0, updated_at = ?"),
  listWarnings: db.prepare("SELECT user_id,count FROM warnings WHERE count > 0 ORDER BY count DESC, user_id ASC"),
  addIncident: db.prepare("INSERT INTO incidents (created_at,type,user_id,user_tag,guild_id,guild_name,channel_id,channel_name,reason,content,action,severity) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"),
  listIncidents: db.prepare("SELECT id,created_at,type,user_tag,reason,action,severity FROM incidents ORDER BY id DESC LIMIT ?"),
};

const runtimeState = { openaiFailures: 0, moderationFailures: 0, raidBlocks: 0, alertsSent: 0 };
const antiRaidState = { userMessageTimestamps: new Map(), channelContentCounters: new Map() };
const authSessions = new Map();
const oauthStateStore = new Map();
const alertCooldownByKey = new Map();

let client;

function nowIso() { return new Date().toISOString(); }

function loadConfig() {
  try {
    const parsed = JSON.parse(fs.readFileSync(CONFIG_PATH, "utf8")) || {};
    const cfg = { ...DEFAULT_CONFIG, ...parsed };
    cfg.antiRaid = { ...DEFAULT_CONFIG.antiRaid, ...(parsed.antiRaid || {}) };
    cfg.health = { ...DEFAULT_CONFIG.health, ...(parsed.health || {}) };
    cfg.dashboardAuth = { ...DEFAULT_CONFIG.dashboardAuth, ...(parsed.dashboardAuth || {}) };
    cfg.falsePositive = { ...DEFAULT_CONFIG.falsePositive, ...(parsed.falsePositive || {}) };
    if (!Array.isArray(cfg.bypassUsers)) cfg.bypassUsers = [];
    if (!Array.isArray(cfg.dashboardAuth.allowedRoleIds)) cfg.dashboardAuth.allowedRoleIds = [];
    if (!Array.isArray(cfg.dashboardAuth.allowedUserIds)) cfg.dashboardAuth.allowedUserIds = [];
    if (!Array.isArray(cfg.falsePositive.allowedUsers)) cfg.falsePositive.allowedUsers = [];
    if (!Array.isArray(cfg.falsePositive.allowedChannels)) cfg.falsePositive.allowedChannels = [];
    if (!Array.isArray(cfg.falsePositive.allowedPhrases)) cfg.falsePositive.allowedPhrases = [];
    return cfg;
  } catch {
    return JSON.parse(JSON.stringify(DEFAULT_CONFIG));
  }
}

function saveConfig(data) { fs.writeFileSync(CONFIG_PATH, JSON.stringify(data, null, 2)); }

function migrateWarningsFromJson() {
  try {
    if (!fs.existsSync(WARNINGS_PATH)) return;
    const parsed = JSON.parse(fs.readFileSync(WARNINGS_PATH, "utf8"));
    if (!parsed || typeof parsed !== "object") return;
    for (const [uid, count] of Object.entries(parsed)) {
      const n = Number(count) || 0;
      if (n > 0) sql.upsertWarning.run(uid, n, nowIso());
    }
  } catch {}
}

function getWarningCount(uid) { const r = sql.getWarning.get(uid); return r ? Number(r.count) : 0; }
function addWarning(uid) { const n = getWarningCount(uid) + 1; sql.upsertWarning.run(uid, n, nowIso()); return n; }
function resetWarnings(uid) { sql.upsertWarning.run(uid, 0, nowIso()); }
function resetAllWarnings() { sql.resetAllWarnings.run(nowIso()); }
function getWarningRows() { return sql.listWarnings.all().map((r) => ({ userId: r.user_id, count: Number(r.count) || 0 })); }
function listIncidents(limit = 50) { return sql.listIncidents.all(Math.max(1, Math.min(limit, 200))); }

function addIncident(entry) {
  const out = sql.addIncident.run(nowIso(), entry.type || "UNKNOWN", entry.userId || null, entry.userTag || null, entry.guildId || null, entry.guildName || null, entry.channelId || null, entry.channelName || null, entry.reason || null, entry.content || null, entry.action || null, entry.severity || null);
  return Number(out.lastInsertRowid);
}

function parseCookies(req) {
  const raw = req.headers.cookie || "";
  const out = {};
  raw.split(";").forEach((c) => {
    const i = c.indexOf("=");
    if (i < 0) return;
    out[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1).trim());
  });
  return out;
}

function setCookie(res, key, val, maxAgeMs) {
  res.setHeader("Set-Cookie", `${key}=${encodeURIComponent(val)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${Math.floor(maxAgeMs / 1000)}`);
}

function clearCookie(res, key) { res.setHeader("Set-Cookie", `${key}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`); }

function getSession(req) {
  const sid = parseCookies(req)[SESSION_COOKIE];
  if (!sid) return null;
  const s = authSessions.get(sid);
  if (!s) return null;
  if (s.expiresAt <= Date.now()) { authSessions.delete(sid); return null; }
  return { sid, ...s };
}

setInterval(() => {
  const now = Date.now();
  for (const [sid, s] of authSessions.entries()) if (s.expiresAt <= now) authSessions.delete(sid);
  for (const [st, s] of oauthStateStore.entries()) if (s.expiresAt <= now) oauthStateStore.delete(st);
}, 60_000);

function escapeHtml(v) {
  return String(v).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/'/g, "&#39;");
}

function normalizeContent(v) {
  return String(v || "").toLowerCase().replace(/https?:\/\/\S+/g, "[url]").replace(/\s+/g, " ").trim();
}

async function sendAlert(type, message, options = {}) {
  const cfg = loadConfig();
  if (!cfg.logUserId || !client?.isReady?.()) return;

  if (options.cooldownMs && options.cooldownKey) {
    const last = alertCooldownByKey.get(options.cooldownKey) || 0;
    const now = Date.now();
    if (now - last < options.cooldownMs) return;
    alertCooldownByKey.set(options.cooldownKey, now);
  }

  try {
    const user = await client.users.fetch(cfg.logUserId);
    await user.send(`[${type}]\n${message}`);
    runtimeState.alertsSent += 1;
  } catch {}
}

async function sendHealthAlert(message) {
  const cfg = loadConfig();
  if (!cfg.health.alertsEnabled) return;
  await sendAlert("HEALTH", message, { cooldownMs: cfg.health.alertCooldownMs, cooldownKey: "health" });
}

function getHealthSnapshot() {
  const cfg = loadConfig();
  return {
    status: "ok",
    timestamp: nowIso(),
    uptimeSec: Math.floor(process.uptime()),
    botReady: Boolean(client?.isReady?.()),
    botUser: client?.user?.tag || null,
    openaiEnabled: Boolean(process.env.OPENAI_API_KEY),
    raidMode: Boolean(cfg.raidMode),
    counters: { ...runtimeState },
    memory: process.memoryUsage(),
  };
}

function isFalsePositiveBypass(message, config) {
  return config.falsePositive.allowedUsers.includes(message.author.id) || config.falsePositive.allowedChannels.includes(message.channel.id);
}

function hasAllowedPhrase(content, config) {
  const txt = String(content || "").toLowerCase();
  return config.falsePositive.allowedPhrases.some((p) => p && txt.includes(String(p).toLowerCase()));
}

const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;

async function checkModeration(input) {
  if (!openai) return { flagged: false, categories: {} };
  try {
    const mod = await openai.moderations.create({ model: "omni-moderation-latest", input });
    return mod.results[0];
  } catch (e) {
    runtimeState.openaiFailures += 1;
    const cfg = loadConfig();
    if (runtimeState.openaiFailures >= cfg.health.openaiFailureAlertThreshold) {
      await sendHealthAlert(`OpenAI failures: ${runtimeState.openaiFailures}. Latest: ${e?.message || e}`);
      addIncident({ type: "HEALTH", reason: "openai_failures", action: "alerted", severity: "high", content: String(e?.message || e) });
    }
    throw e;
  }
}

async function registerSlashCommands() {
  if (!client.application) return;
  await client.application.commands.set([
    { name: "warnings", description: "Check warning count", options: [{ name: "user", description: "target user", type: 6, required: false }] },
    { name: "raidmode", description: "Toggle raid mode", options: [{ name: "action", description: "on/off/status", type: 3, required: true, choices: [{ name: "on", value: "on" }, { name: "off", value: "off" }, { name: "status", value: "status" }] }] },
    { name: "health", description: "Show health" },
  ]);
}

function hasModPerms(interaction) {
  const m = interaction.member;
  return Boolean(m && m.permissions && m.permissions.has(PermissionsBitField.Flags.ModerateMembers));
}

async function createIncidentThread(message, details) {
  try {
    const msg = await message.channel.send(`Moderation incident: ${message.author} in <#${message.channel.id}>`);
    if (typeof msg.startThread !== "function") return;
    const th = await msg.startThread({ name: `incident-${message.author.username}`.slice(0, 100), autoArchiveDuration: 60, reason: "Automated incident" });
    await th.send(details);
  } catch {}
}

function markUserMessage(userId, now, windowMs) {
  const arr = antiRaidState.userMessageTimestamps.get(userId) || [];
  const next = arr.filter((t) => t >= now - windowMs);
  next.push(now);
  antiRaidState.userMessageTimestamps.set(userId, next);
  return next.length;
}

function markContentMessage(channelId, norm, now, windowMs) {
  if (!norm) return 0;
  const key = `${channelId}:${norm}`;
  const old = antiRaidState.channelContentCounters.get(key);
  if (!old || old.firstSeenAt < now - windowMs) {
    antiRaidState.channelContentCounters.set(key, { count: 1, firstSeenAt: now });
    return 1;
  }
  old.count += 1;
  antiRaidState.channelContentCounters.set(key, old);
  return old.count;
}

async function evaluateAntiRaid(message, config) {
  const s = config.antiRaid;
  if (!s.enabled) return null;

  const now = Date.now();
  const burst = markUserMessage(message.author.id, now, s.burstWindowMs);
  if (burst >= s.burstThreshold) return `Burst spam (${burst} msgs/${Math.floor(s.burstWindowMs / 1000)}s)`;

  const norm = normalizeContent(message.content);
  if (norm.length >= 3) {
    const dup = markContentMessage(message.channel.id, norm, now, s.duplicateWindowMs);
    if (dup >= s.duplicateThreshold) return `Duplicate spam (${dup} repeats/${Math.floor(s.duplicateWindowMs / 1000)}s)`;
  }

  if (config.raidMode && s.joinAgeFilterEnabled) {
    const member = message.member || (await message.guild.members.fetch(message.author.id).catch(() => null));
    const joinedAt = member?.joinedTimestamp;
    if (joinedAt && now - joinedAt < s.minJoinAgeMinutes * 60 * 1000) {
      const hasLink = /(https?:\/\/|discord\.gg\/|discordapp\.com\/invite\/)/i.test(message.content || "");
      if ((hasLink || message.attachments.size > 0) && s.blockLinksForNewJoins) return `Join-age filter blocked message (<${s.minJoinAgeMinutes}m member)`;
    }
  }

  return null;
}

async function discordFetch(pathName, accessToken, init = {}) {
  return fetch(`https://discord.com/api/v10${pathName}`, { ...init, headers: { ...(init.headers || {}), Authorization: `Bearer ${accessToken}` } });
}

async function isDashboardUserAuthorized(accessToken, userId, cfg) {
  if (!cfg.dashboardAuth.enabled) return true;
  if (cfg.dashboardAuth.allowedUserIds.includes(userId)) return true;
  if (!cfg.dashboardAuth.guildId) return false;

  const memberRes = await discordFetch(`/users/@me/guilds/${cfg.dashboardAuth.guildId}/member`, accessToken);
  if (!memberRes.ok) return false;
  const member = await memberRes.json();
  const roles = Array.isArray(member.roles) ? member.roles : [];
  if (cfg.dashboardAuth.allowedRoleIds.length === 0) return true;
  return cfg.dashboardAuth.allowedRoleIds.some((id) => roles.includes(id));
}

client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers, GatewayIntentBits.DirectMessages], partials: [Partials.Channel] });

client.on("clientReady", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  try { await registerSlashCommands(); } catch (e) { await sendHealthAlert(`Slash sync failed: ${e?.message || e}`); }
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand()) return;
  if (!interaction.inGuild()) return interaction.reply({ content: "Use this command in a server.", ephemeral: true });
  if (!hasModPerms(interaction)) return interaction.reply({ content: "You need Moderate Members permission.", ephemeral: true });

  if (interaction.commandName === "warnings") {
    const target = interaction.options.getUser("user") || interaction.user;
    const count = getWarningCount(target.id);
    const cfg = loadConfig();
    return interaction.reply({ content: `${target.tag} has ${count}/${cfg.warningLimit} warnings.`, ephemeral: true });
  }

  if (interaction.commandName === "raidmode") {
    const action = interaction.options.getString("action", true);
    const cfg = loadConfig();
    if (action === "status") return interaction.reply({ content: `Raid mode is ${cfg.raidMode ? "ON" : "OFF"}.`, ephemeral: true });
    cfg.raidMode = action === "on";
    saveConfig(cfg);
    return interaction.reply({ content: `Raid mode set to ${cfg.raidMode ? "ON" : "OFF"}.`, ephemeral: true });
  }

  if (interaction.commandName === "health") {
    const h = getHealthSnapshot();
    return interaction.reply({ content: `Status: ${h.status}\nUptime: ${h.uptimeSec}s\nBot ready: ${h.botReady}\nOpenAI failures: ${h.counters.openaiFailures}\nRaid blocks: ${h.counters.raidBlocks}`, ephemeral: true });
  }
});

client.on("messageCreate", async (message) => {
  if (!message.guild || message.author.bot) return;

  const cfg = loadConfig();
  if (cfg.bypassUsers.includes(message.author.id)) return;
  if (isFalsePositiveBypass(message, cfg)) return;

  try {
    const antiRaidReason = await evaluateAntiRaid(message, cfg);
    if (antiRaidReason) {
      const member = message.member || (await message.guild.members.fetch(message.author.id));
      if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

      runtimeState.raidBlocks += 1;
      const incidentId = addIncident({
        type: "ANTI_RAID",
        reason: antiRaidReason,
        userId: message.author.id,
        userTag: message.author.tag,
        guildId: message.guild.id,
        guildName: message.guild.name,
        channelId: message.channel.id,
        channelName: message.channel.name || message.channel.id,
        content: message.content || "(no text)",
        action: "delete+timeout",
        severity: "high",
      });

      const details = [
        `Incident #${incidentId}`,
        `Type: Anti-Raid`,
        `Reason: ${antiRaidReason}`,
        `User: ${message.author.tag} (${message.author.id})`,
        `Server: ${message.guild.name}`,
        `Channel: #${message.channel.name || message.channel.id}`,
      ].join("\n");

      await message.delete().catch(() => {});
      await member.timeout(cfg.antiRaid.timeoutDurationMs, "Anti-raid protection triggered").catch(() => {});
      await message.channel.send(`${message.author} blocked by anti-raid protection.`).catch(() => {});
      await createIncidentThread(message, details);
      await sendAlert("ANTI-RAID", details);
      return;
    }

    let input = message.content || "";
    if (message.attachments.size > 0) {
      const urls = [...message.attachments.values()].map((a) => a.url).filter(Boolean).join("\n");
      if (urls) input = `${input}\n${urls}`.trim();
    }

    if (!input) return;
    if (hasAllowedPhrase(message.content, cfg)) return;

    const result = await checkModeration(input);
    if (!result.flagged) return;

    const member = await message.guild.members.fetch(message.author.id);
    if (member.permissions.has(PermissionsBitField.Flags.Administrator)) return;

    const severe =
      !!result.categories?.hate ||
      !!result.categories?.["hate/threatening"] ||
      !!result.categories?.harassment ||
      !!result.categories?.["harassment/threatening"];

    const incidentId = addIncident({
      type: "MODERATION",
      reason: severe ? "severe_violation" : "flagged_content",
      userId: message.author.id,
      userTag: message.author.tag,
      guildId: message.guild.id,
      guildName: message.guild.name,
      channelId: message.channel.id,
      channelName: message.channel.name || message.channel.id,
      content: message.content || "(no text)",
      action: severe ? "delete+timeout(severe)" : "delete+warn/timeout",
      severity: severe ? "high" : "medium",
    });

    const details = [
      `Incident #${incidentId}`,
      `Type: OpenAI Moderation`,
      `User: ${message.author.tag} (${message.author.id})`,
      `Server: ${message.guild.name}`,
      `Channel: #${message.channel.name || message.channel.id}`,
      `Severity: ${severe ? "Severe" : "Standard"}`,
      `Content: ${message.content || "(no text)"}`,
    ].join("\n");

    await createIncidentThread(message, details);
    await message.delete().catch(() => {});

    if (severe) {
      await member.timeout(cfg.timeoutDuration, "Extreme violation");
      resetWarnings(message.author.id);
      await message.channel.send(`${message.author} timed out for severe violation.`);
      await sendAlert("MODERATION", details);
      return;
    }

    const currentWarnings = addWarning(message.author.id);
    if (currentWarnings < cfg.warningLimit) {
      await message.channel.send(`${message.author} warning ${currentWarnings}/${cfg.warningLimit}`);
      await sendAlert("MODERATION", `${details}\nAction: warning ${currentWarnings}/${cfg.warningLimit}`);
      return;
    }

    await member.timeout(cfg.timeoutDuration, "Exceeded warning limit");
    await message.channel.send(`${message.author} timed out (${cfg.warningLimit}/${cfg.warningLimit} warnings).`);
    resetWarnings(message.author.id);
    await sendAlert("MODERATION", `${details}\nAction: timeout at warning limit`);
  } catch (err) {
    runtimeState.moderationFailures += 1;
    addIncident({ type: "HEALTH", reason: "messageCreate_failure", action: "alerted", severity: "high", content: String(err?.message || err) });
    await sendHealthAlert(`messageCreate handler failure: ${err?.message || err}`);
  }
});

process.on("unhandledRejection", async (reason) => {
  addIncident({ type: "HEALTH", reason: "unhandled_rejection", action: "alerted", severity: "high", content: String(reason) });
  await sendHealthAlert(`Unhandled rejection: ${String(reason)}`);
});

process.on("uncaughtException", async (error) => {
  addIncident({ type: "HEALTH", reason: "uncaught_exception", action: "alerted", severity: "high", content: String(error?.message || error) });
  await sendHealthAlert(`Uncaught exception: ${error?.message || error}`);
});

migrateWarningsFromJson();

const token = process.env.DISCORD_TOKEN || process.env.TOKEN;
if (token) {
  client.login(token).catch(async (err) => {
    addIncident({ type: "HEALTH", reason: "discord_login_failed", action: "alerted", severity: "high", content: String(err?.message || err) });
    await sendHealthAlert(`Discord login failed: ${err?.message || err}`);
  });
} else {
  console.error("Missing DISCORD_TOKEN/TOKEN in environment.");
}

const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

const PORT = parseInt(process.env.PORT || String(loadConfig().dashboardPort), 10);

function requireDashboardAuth(req, res, next) {
  const cfg = loadConfig();
  if (!cfg.dashboardAuth.enabled) return next();
  const session = getSession(req);
  if (!session) {
    if ((req.headers.accept || "").includes("text/html")) return res.redirect("/login");
    return res.status(401).json({ message: "Unauthorized" });
  }
  req.dashboardUser = session.user;
  return next();
}

app.get("/login", (req, res) => {
  const cfg = loadConfig();
  if (!cfg.dashboardAuth.enabled) return res.redirect("/");

  const clientId = process.env.DISCORD_CLIENT_ID;
  const redirectUri = process.env.DISCORD_REDIRECT_URI;
  if (!clientId || !redirectUri) return res.status(500).send("Missing DISCORD_CLIENT_ID or DISCORD_REDIRECT_URI");

  const state = crypto.randomBytes(16).toString("hex");
  oauthStateStore.set(state, { expiresAt: Date.now() + 10 * 60 * 1000 });
  const params = new URLSearchParams({ client_id: clientId, response_type: "code", redirect_uri: redirectUri, scope: "identify guilds guilds.members.read", state, prompt: "none" });
  return res.redirect(`https://discord.com/api/oauth2/authorize?${params.toString()}`);
});

app.get("/oauth/callback", async (req, res) => {
  const cfg = loadConfig();
  const { code, state } = req.query;
  if (!code || !state || !oauthStateStore.has(state)) return res.status(400).send("Invalid OAuth state");
  oauthStateStore.delete(state);

  try {
    const clientId = process.env.DISCORD_CLIENT_ID;
    const clientSecret = process.env.DISCORD_CLIENT_SECRET;
    const redirectUri = process.env.DISCORD_REDIRECT_URI;
    if (!clientId || !clientSecret || !redirectUri) return res.status(500).send("OAuth env vars missing");

    const body = new URLSearchParams({ client_id: clientId, client_secret: clientSecret, grant_type: "authorization_code", code: String(code), redirect_uri: redirectUri });
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body });
    if (!tokenRes.ok) return res.status(401).send("OAuth token exchange failed");

    const tokenJson = await tokenRes.json();
    const accessToken = tokenJson.access_token;
    if (!accessToken) return res.status(401).send("OAuth token missing");

    const meRes = await discordFetch("/users/@me", accessToken);
    if (!meRes.ok) return res.status(401).send("Could not load Discord profile");
    const me = await meRes.json();

    const allowed = await isDashboardUserAuthorized(accessToken, me.id, cfg);
    if (!allowed) return res.status(403).send("Not authorized for dashboard");

    const sid = crypto.randomBytes(24).toString("hex");
    authSessions.set(sid, { user: { id: me.id, username: me.username, discriminator: me.discriminator }, expiresAt: Date.now() + SESSION_TTL_MS });
    setCookie(res, SESSION_COOKIE, sid, SESSION_TTL_MS);
    return res.redirect("/");
  } catch {
    return res.status(500).send("OAuth callback failed");
  }
});

app.get("/logout", (req, res) => {
  const session = getSession(req);
  if (session) authSessions.delete(session.sid);
  clearCookie(res, SESSION_COOKIE);
  return res.redirect("/login");
});

app.get("/health", (_req, res) => res.status(200).json(getHealthSnapshot()));
app.get("/ping", (_req, res) => res.send("Pong!"));

app.use((req, res, next) => {
  if (req.path === "/api/health") return next();
  if (req.path === "/" || req.path.startsWith("/api/")) return requireDashboardAuth(req, res, next);
  return next();
});

app.get("/api/health", (_req, res) => res.json(getHealthSnapshot()));

app.get("/api/dashboard", (req, res) => {
  const cfg = loadConfig();
  res.json({
    warningLimit: cfg.warningLimit,
    timeoutDuration: cfg.timeoutDuration,
    raidMode: cfg.raidMode,
    antiRaid: cfg.antiRaid,
    dashboardAuth: cfg.dashboardAuth,
    bypassUsers: cfg.bypassUsers,
    falsePositive: cfg.falsePositive,
    warningRows: getWarningRows(),
    incidents: listIncidents(60),
    viewer: req.dashboardUser || null,
  });
});

app.post("/api/raid-mode", (req, res) => {
  const cfg = loadConfig();
  cfg.raidMode = Boolean(req.body.enabled);
  saveConfig(cfg);
  res.json({ ok: true, raidMode: cfg.raidMode });
});

app.post("/api/config/dashboard-auth", (req, res) => {
  const cfg = loadConfig();
  cfg.dashboardAuth.enabled = Boolean(req.body.enabled);
  cfg.dashboardAuth.guildId = String(req.body.guildId || "").trim();
  cfg.dashboardAuth.allowedRoleIds = String(req.body.allowedRoleIds || "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);
  cfg.dashboardAuth.allowedUserIds = String(req.body.allowedUserIds || "")
    .split(",")
    .map((x) => x.trim())
    .filter(Boolean);
  saveConfig(cfg);
  res.json({ ok: true, dashboardAuth: cfg.dashboardAuth });
});

app.post("/api/config/anti-raid", (req, res) => {
  const cfg = loadConfig();
  const toNum = (v, d) => {
    const n = Number(v);
    return Number.isFinite(n) ? n : d;
  };

  cfg.antiRaid.enabled = Boolean(req.body.enabled);
  cfg.antiRaid.burstWindowMs = toNum(req.body.burstWindowMs, cfg.antiRaid.burstWindowMs);
  cfg.antiRaid.burstThreshold = toNum(req.body.burstThreshold, cfg.antiRaid.burstThreshold);
  cfg.antiRaid.duplicateWindowMs = toNum(req.body.duplicateWindowMs, cfg.antiRaid.duplicateWindowMs);
  cfg.antiRaid.duplicateThreshold = toNum(req.body.duplicateThreshold, cfg.antiRaid.duplicateThreshold);
  cfg.antiRaid.timeoutDurationMs = toNum(req.body.timeoutDurationMs, cfg.antiRaid.timeoutDurationMs);
  cfg.antiRaid.joinAgeFilterEnabled = Boolean(req.body.joinAgeFilterEnabled);
  cfg.antiRaid.minJoinAgeMinutes = toNum(req.body.minJoinAgeMinutes, cfg.antiRaid.minJoinAgeMinutes);
  cfg.antiRaid.blockLinksForNewJoins = Boolean(req.body.blockLinksForNewJoins);

  saveConfig(cfg);
  res.json({ ok: true, antiRaid: cfg.antiRaid });
});

app.post("/api/bypass/add", (req, res) => {
  const userId = String(req.body.userId || "").trim();
  if (!userId) return res.status(400).json({ message: "userId is required" });
  const cfg = loadConfig();
  if (!cfg.bypassUsers.includes(userId)) { cfg.bypassUsers.push(userId); saveConfig(cfg); }
  res.json({ ok: true });
});

app.post("/api/bypass/remove", (req, res) => {
  const userId = String(req.body.userId || "").trim();
  const cfg = loadConfig();
  cfg.bypassUsers = cfg.bypassUsers.filter((id) => id !== userId);
  saveConfig(cfg);
  res.json({ ok: true });
});

app.post("/api/warnings/reset", (req, res) => {
  const userId = String(req.body.userId || "").trim();
  if (!userId) { resetAllWarnings(); return res.json({ ok: true, scope: "all" }); }
  resetWarnings(userId);
  return res.json({ ok: true, scope: "single" });
});

app.post("/api/false-positive/add", (req, res) => {
  const kind = String(req.body.kind || "").trim();
  const value = String(req.body.value || "").trim();
  if (!kind || !value) return res.status(400).json({ message: "kind and value required" });
  const map = { users: "allowedUsers", channels: "allowedChannels", phrases: "allowedPhrases" };
  const cfg = loadConfig();
  const key = map[kind];
  if (!key) return res.status(400).json({ message: "invalid kind" });
  if (!cfg.falsePositive[key].includes(value)) { cfg.falsePositive[key].push(value); saveConfig(cfg); }
  return res.json({ ok: true });
});

app.post("/api/false-positive/remove", (req, res) => {
  const kind = String(req.body.kind || "").trim();
  const value = String(req.body.value || "").trim();
  if (!kind || !value) return res.status(400).json({ message: "kind and value required" });
  const map = { users: "allowedUsers", channels: "allowedChannels", phrases: "allowedPhrases" };
  const cfg = loadConfig();
  const key = map[kind];
  if (!key) return res.status(400).json({ message: "invalid kind" });
  cfg.falsePositive[key] = cfg.falsePositive[key].filter((x) => x !== value);
  saveConfig(cfg);
  return res.json({ ok: true });
});

app.get("/", (req, res) => {
  const cfg = loadConfig();
  const health = getHealthSnapshot();
  const warningRows = getWarningRows();
  const incidents = listIncidents(40);

  const warningHTML = warningRows
    .map(
      (r) =>
        `<tr><td><code>${escapeHtml(r.userId)}</code></td><td><span class='badge'>${r.count}/${cfg.warningLimit}</span></td><td><button class='btn ghost' onclick="resetOne('${escapeHtml(r.userId)}')">Reset</button></td></tr>`,
    )
    .join("");
  const bypassHTML = cfg.bypassUsers
    .map(
      (id) =>
        `<li><code>${escapeHtml(id)}</code><button class='btn ghost' onclick="removeBypass('${escapeHtml(id)}')">Remove</button></li>`,
    )
    .join("");
  const fpUsers = cfg.falsePositive.allowedUsers
    .map(
      (v) =>
        `<li><code>${escapeHtml(v)}</code><button class='btn ghost' onclick="removeFp('users','${escapeHtml(v)}')">Remove</button></li>`,
    )
    .join("");
  const fpChannels = cfg.falsePositive.allowedChannels
    .map(
      (v) =>
        `<li><code>${escapeHtml(v)}</code><button class='btn ghost' onclick="removeFp('channels','${escapeHtml(v)}')">Remove</button></li>`,
    )
    .join("");
  const fpPhrases = cfg.falsePositive.allowedPhrases
    .map(
      (v) =>
        `<li><code>${escapeHtml(v)}</code><button class='btn ghost' onclick="removeFp('phrases','${escapeHtml(v)}')">Remove</button></li>`,
    )
    .join("");
  const incidentsHTML = incidents
    .map(
      (i) =>
        `<tr><td>${i.id}</td><td>${escapeHtml(i.created_at)}</td><td>${escapeHtml(i.type)}</td><td>${escapeHtml(i.user_tag || "-")}</td><td>${escapeHtml(i.reason || "-")}</td><td>${escapeHtml(i.action || "-")}</td></tr>`,
    )
    .join("");

  res.send(`<!doctype html>
<html>
<head>
  <meta charset='UTF-8'>
  <meta name='viewport' content='width=device-width,initial-scale=1'>
  <title>Dashboard</title>
  <style>
    body{margin:0;font-family:Segoe UI,sans-serif;background:#0c162c;color:#ecf2ff}
    .wrap{max-width:1280px;margin:0 auto;padding:16px}
    .hero,.card{background:#132342;border:1px solid #294272;border-radius:12px;padding:14px}
    .hero{margin-bottom:12px}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:12px}
    .wide{grid-column:1/-1}
    .btn{border:0;border-radius:8px;padding:8px 10px;cursor:pointer}
    .primary{background:#1dd3b0;color:#05231d}
    .ghost{background:#2b4776;color:#fff}
    .danger{background:#ff7b54;color:#2d1105}
    input,select{width:100%;padding:8px;border-radius:8px;border:1px solid #294272;background:#0e1d3a;color:#fff;margin-bottom:8px}
    table{width:100%;border-collapse:collapse}
    th,td{text-align:left;padding:8px;border-bottom:1px solid #2a426f}
    .badge{background:#1f3969;border:1px solid #355591;border-radius:999px;padding:3px 8px}
    ul{list-style:none;padding:0;margin:0}
    li{display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #2a426f}
  </style>
</head>
<body>
  <main class='wrap'>
    <section class='hero'>
      <h1>Moderation Dashboard</h1>
      <div>User: ${escapeHtml(req.dashboardUser?.username || "unknown")} | Bot: ${health.botReady ? "online" : "offline"} | Raid mode: ${cfg.raidMode ? "ON" : "OFF"}</div>
      <div>Warnings in SQLite bot.db | <a href='/logout' style='color:#9de8ff'>Logout</a></div>
    </section>

    <section class='grid'>
      <article class='card'>
        <h3>Anti-Raid Quick Toggle</h3>
        <div>Burst ${cfg.antiRaid.burstThreshold}/${Math.floor(cfg.antiRaid.burstWindowMs / 1000)}s, duplicate ${cfg.antiRaid.duplicateThreshold}/${Math.floor(cfg.antiRaid.duplicateWindowMs / 1000)}s</div>
        <p><button class='btn primary' onclick='setRaidMode(true)'>Enable</button> <button class='btn ghost' onclick='setRaidMode(false)'>Disable</button></p>
      </article>

      <article class='card'>
        <h3>Anti-Raid Advanced</h3>
        <label><input id='ar_enabled' type='checkbox' ${cfg.antiRaid.enabled ? "checked" : ""}> Enabled</label>
        <input id='ar_burst_window' value='${cfg.antiRaid.burstWindowMs}' placeholder='burstWindowMs'>
        <input id='ar_burst_threshold' value='${cfg.antiRaid.burstThreshold}' placeholder='burstThreshold'>
        <input id='ar_dup_window' value='${cfg.antiRaid.duplicateWindowMs}' placeholder='duplicateWindowMs'>
        <input id='ar_dup_threshold' value='${cfg.antiRaid.duplicateThreshold}' placeholder='duplicateThreshold'>
        <input id='ar_timeout' value='${cfg.antiRaid.timeoutDurationMs}' placeholder='timeoutDurationMs'>
        <label><input id='ar_join_age_enabled' type='checkbox' ${cfg.antiRaid.joinAgeFilterEnabled ? "checked" : ""}> Join-age filter enabled</label>
        <input id='ar_join_age' value='${cfg.antiRaid.minJoinAgeMinutes}' placeholder='minJoinAgeMinutes'>
        <label><input id='ar_block_links' type='checkbox' ${cfg.antiRaid.blockLinksForNewJoins ? "checked" : ""}> Block links/media for new joins</label>
        <button class='btn primary' onclick='saveAntiRaid()'>Save Anti-Raid</button>
      </article>

      <article class='card'>
        <h3>Dashboard Auth</h3>
        <label><input id='da_enabled' type='checkbox' ${cfg.dashboardAuth.enabled ? "checked" : ""}> OAuth auth enabled</label>
        <input id='da_guild_id' value='${escapeHtml(cfg.dashboardAuth.guildId)}' placeholder='Guild ID'>
        <input id='da_roles' value='${escapeHtml(cfg.dashboardAuth.allowedRoleIds.join(","))}' placeholder='Allowed role IDs (comma separated)'>
        <input id='da_users' value='${escapeHtml(cfg.dashboardAuth.allowedUserIds.join(","))}' placeholder='Allowed user IDs (comma separated)'>
        <button class='btn primary' onclick='saveDashboardAuth()'>Save Dashboard Auth</button>
      </article>

      <article class='card'>
        <h3>Health</h3>
        <div>Uptime: <b>${health.uptimeSec}s</b></div>
        <div>OpenAI failures: <b>${health.counters.openaiFailures}</b></div>
        <div>Moderation failures: <b>${health.counters.moderationFailures}</b></div>
        <div>Raid blocks: <b>${health.counters.raidBlocks}</b></div>
        <div>Alerts sent: <b>${health.counters.alertsSent}</b></div>
      </article>

      <article class='card'>
        <h3>Bypass Users</h3>
        <input id='bypassInput' placeholder='Discord user ID'>
        <button class='btn primary' onclick='addBypass()'>Add</button>
        <ul>${bypassHTML || "<li>None</li>"}</ul>
      </article>

      <article class='card'>
        <h3>False Positives</h3>
        <select id='fpKind'><option value='users'>users</option><option value='channels'>channels</option><option value='phrases'>phrases</option></select>
        <input id='fpValue' placeholder='User/channel/phrase'>
        <button class='btn primary' onclick='addFp()'>Add</button>
        <h4>Users</h4><ul>${fpUsers || "<li>None</li>"}</ul>
        <h4>Channels</h4><ul>${fpChannels || "<li>None</li>"}</ul>
        <h4>Phrases</h4><ul>${fpPhrases || "<li>None</li>"}</ul>
      </article>

      <article class='card wide'>
        <h3>Warnings</h3>
        <button class='btn danger' onclick='resetAll()'>Reset All</button>
        <table><thead><tr><th>User ID</th><th>Count</th><th>Action</th></tr></thead><tbody>${warningHTML || "<tr><td colspan='3'>No warnings</td></tr>"}</tbody></table>
      </article>

      <article class='card wide'>
        <h3>Incident Log</h3>
        <table><thead><tr><th>ID</th><th>Time</th><th>Type</th><th>User</th><th>Reason</th><th>Action</th></tr></thead><tbody>${incidentsHTML || "<tr><td colspan='6'>No incidents</td></tr>"}</tbody></table>
      </article>
    </section>
  </main>
  <script>
    async function post(u,b){const r=await fetch(u,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b||{})});if(!r.ok){const d=await r.json().catch(()=>({}));throw new Error(d.message||'Request failed')}}
    async function setRaidMode(e){await post('/api/raid-mode',{enabled:e});location.reload()}
    async function addBypass(){const v=(document.getElementById('bypassInput').value||'').trim();if(!v)return;await post('/api/bypass/add',{userId:v});location.reload()}
    async function removeBypass(v){await post('/api/bypass/remove',{userId:v});location.reload()}
    async function resetOne(v){await post('/api/warnings/reset',{userId:v});location.reload()}
    async function resetAll(){await post('/api/warnings/reset',{});location.reload()}
    async function addFp(){const kind=document.getElementById('fpKind').value;const value=(document.getElementById('fpValue').value||'').trim();if(!value)return;await post('/api/false-positive/add',{kind,value});location.reload()}
    async function removeFp(kind,value){await post('/api/false-positive/remove',{kind,value});location.reload()}
    async function saveDashboardAuth(){
      await post('/api/config/dashboard-auth',{
        enabled:document.getElementById('da_enabled').checked,
        guildId:(document.getElementById('da_guild_id').value||'').trim(),
        allowedRoleIds:(document.getElementById('da_roles').value||'').trim(),
        allowedUserIds:(document.getElementById('da_users').value||'').trim(),
      });
      location.reload();
    }
    async function saveAntiRaid(){
      await post('/api/config/anti-raid',{
        enabled:document.getElementById('ar_enabled').checked,
        burstWindowMs:document.getElementById('ar_burst_window').value,
        burstThreshold:document.getElementById('ar_burst_threshold').value,
        duplicateWindowMs:document.getElementById('ar_dup_window').value,
        duplicateThreshold:document.getElementById('ar_dup_threshold').value,
        timeoutDurationMs:document.getElementById('ar_timeout').value,
        joinAgeFilterEnabled:document.getElementById('ar_join_age_enabled').checked,
        minJoinAgeMinutes:document.getElementById('ar_join_age').value,
        blockLinksForNewJoins:document.getElementById('ar_block_links').checked,
      });
      location.reload();
    }
  </script>
</body>
</html>`);
});

const selfPingUrl = process.env.SELF_PING_URL;
if (selfPingUrl) {
  setInterval(() => {
    http.get(selfPingUrl).on("error", () => {});
  }, 280000);
}

app.listen(PORT, () => {
  console.log(`Dashboard running on port ${PORT}`);
});
