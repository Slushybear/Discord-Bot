import { Client, GatewayIntentBits, Message } from "discord.js";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export async function startBot() {
  const token = process.env.DISCORD_TOKEN || process.env.TOKEN;
  if (!token) {
    console.warn("DISCORD_TOKEN not found, skipping bot startup");
    return;
  }

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
    ],
  });

  client.once("ready", () => {
    console.log(`Logged in as ${client.user?.tag}!`);
  });

  client.on("messageCreate", async (message: Message) => {
    if (message.author.bot) return;

    // Basic AI response if mentioned
    if (client.user && message.mentions.has(client.user)) {
      try {
        const response = await openai.chat.completions.create({
          model: "gpt-4o",
          messages: [
            { role: "system", content: "You are a helpful Discord bot." },
            { role: "user", content: message.content.replace(`<@${client.user.id}>`, "").trim() },
          ],
        });

        const reply = response.choices[0]?.message?.content || "I'm not sure what to say.";
        await message.reply(reply);
      } catch (error) {
        console.error("OpenAI Error:", error);
        await message.reply("Sorry, I'm having trouble thinking right now.");
      }
    }
  });

  try {
    await client.login(token);
  } catch (err) {
    console.error("Failed to login to Discord:", err);
  }
}
