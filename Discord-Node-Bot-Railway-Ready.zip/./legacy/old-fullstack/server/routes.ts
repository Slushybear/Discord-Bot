import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get("/api/messages", async (req, res) => {
    const messages = await storage.getMessages();
    res.json(messages);
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const data = insertMessageSchema.parse(req.body);
      const webhookUrl = process.env.DISCORD_WEBHOOK_URL;

      if (!webhookUrl) {
        throw new Error("DISCORD_WEBHOOK_URL environment variable is not set");
      }

      // Send to Discord Webhook
      const response = await fetch(webhookUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          content: data.content,
        }),
      });

      let success = response.ok;
      let error = undefined;

      if (!success) {
        error = `Discord API returned ${response.status}: ${response.statusText}`;
      }

      const message = await storage.createMessage({
        content: data.content,
        success,
        error,
      });

      if (!success) {
        res.status(500).json(message);
      } else {
        res.status(201).json(message);
      }
    } catch (e) {
      if (e instanceof z.ZodError) {
        res.status(400).json(e.errors);
      } else if (e instanceof Error) {
        res.status(500).json({ message: e.message });
      } else {
        res.status(500).json({ message: "Internal Server Error" });
      }
    }
  });

  return httpServer;
}
