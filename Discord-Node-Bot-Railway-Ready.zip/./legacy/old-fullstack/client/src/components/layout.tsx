import { ReactNode } from "react";
import { Bot, BarChart3, Settings, Shield } from "lucide-react";
import { Link, useLocation } from "wouter";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();

  const navItems = [
    { icon: Bot, label: "Webhook Manager", href: "/" },
    // Placeholder links for visual completeness
    { icon: BarChart3, label: "Analytics", href: "/analytics" },
    { icon: Shield, label: "Moderation", href: "/moderation" },
    { icon: Settings, label: "Settings", href: "/settings" },
  ];

  return (
    <div className="flex h-screen w-full overflow-hidden bg-secondary">
      {/* Sidebar */}
      <aside className="w-[72px] flex flex-col items-center py-4 gap-4 bg-secondary shadow-xl z-20">
        <div className="w-12 h-12 rounded-[16px] bg-primary flex items-center justify-center text-white mb-2 shadow-lg shadow-primary/20 hover:rounded-[12px] transition-all duration-300 cursor-pointer">
          <Bot size={28} />
        </div>
        
        <div className="w-8 h-[2px] bg-white/10 rounded-full mb-2" />

        {navItems.map((item) => (
          <Link key={item.href} href={item.href} className="group relative w-12 h-12 flex items-center justify-center">
            {/* Active Indicator Pill */}
            <div className={`
              absolute left-[-16px] w-2 bg-white rounded-r-lg transition-all duration-300
              ${location === item.href ? 'h-10' : 'h-2 group-hover:h-5 opacity-0 group-hover:opacity-100'}
            `} />
            
            {/* Icon Container */}
            <div className={`
              w-12 h-12 flex items-center justify-center rounded-[24px] transition-all duration-300
              ${location === item.href 
                ? 'bg-primary text-white rounded-[16px]' 
                : 'bg-card text-primary group-hover:bg-primary group-hover:text-white group-hover:rounded-[16px]'}
            `}>
              <item.icon size={24} />
            </div>

            {/* Tooltip */}
            <div className="absolute left-14 bg-black px-3 py-1.5 rounded-md text-xs font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap shadow-lg z-50">
              {item.label}
              <div className="absolute top-1/2 left-[-4px] -mt-1 border-4 border-transparent border-r-black" />
            </div>
          </Link>
        ))}
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 bg-background rounded-tl-[30px] overflow-hidden shadow-2xl flex flex-col relative z-10 my-0 mr-0">
        <div className="h-14 border-b border-black/10 bg-background flex items-center px-6 shadow-sm z-20 shrink-0">
          <HashIcon />
          <h1 className="font-bold text-white ml-2 text-md">webhook-logs</h1>
          <div className="ml-4 h-6 w-[1px] bg-white/10" />
          <span className="ml-4 text-xs font-medium text-muted-foreground truncate">
            Manage your Discord webhook integration and view message history
          </span>
        </div>
        
        <div className="flex-1 overflow-y-auto p-6 md:p-8 scroll-smooth">
          <div className="max-w-6xl mx-auto w-full">
            {children}
          </div>
        </div>
      </main>
    </div>
  );
}

function HashIcon() {
  return (
    <svg className="text-muted-foreground" width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M10 3L8 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M16 3L14 21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M3.5 9H21.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M2.5 15H20.5" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
