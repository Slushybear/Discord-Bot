import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { type InsertMessage } from "@shared/schema";
import { api } from "@shared/routes"; // Importing the manifest

// Types derived from schema/routes
type Message = {
  id: number;
  content: string;
  sentAt: string | null;
  success: boolean | null;
  error: string | null;
};

// GET /api/messages
export function useMessages() {
  return useQuery({
    queryKey: [api.messages.list.path],
    queryFn: async () => {
      const res = await fetch(api.messages.list.path);
      if (!res.ok) throw new Error("Failed to fetch messages");
      return await res.json() as Message[];
    },
  });
}

// POST /api/messages
export function useSendMessage() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertMessage) => {
      const res = await fetch(api.messages.create.path, {
        method: api.messages.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.message || "Failed to send message");
      }
      
      return await res.json() as Message;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.messages.list.path] });
    },
  });
}
