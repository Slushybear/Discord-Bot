## Packages
date-fns | Formatting timestamps for message history
framer-motion | Smooth animations for list items and interactions

## Notes
Discord-themed UI with dark mode default
Backend handles actual webhook dispatch
