# Overview

This is a Discord bot management application with a web dashboard. The project has two main parts:

1. **Discord Bot** — A bot that connects to Discord, responds to mentions using OpenAI's GPT-4o, manages user warnings, and sends messages via Discord webhooks.
2. **Web Dashboard** — A Discord-themed React frontend that lets users send messages through Discord webhooks and view message history. It has a dark theme inspired by Discord's UI.

The web dashboard acts as a webhook manager — users type messages in the browser, they get sent to a Discord channel via webhook, and the history is stored in a PostgreSQL database.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend (client/)
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight router)
- **State Management**: TanStack React Query for server state
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming, Discord-inspired dark theme
- **Animations**: Framer Motion for list item animations
- **Build Tool**: Vite with React plugin
- **Path Aliases**: `@/` maps to `client/src/`, `@shared/` maps to `shared/`

The frontend has a Discord-style sidebar layout with navigation for Webhook Manager, Analytics, Moderation, and Settings (only Webhook Manager is fully implemented). The main page is a dashboard split into a message composer and message history panel.

## Backend (server/)
- **Framework**: Express.js with TypeScript
- **Database**: PostgreSQL via `pg` pool + Drizzle ORM
- **Schema Management**: Drizzle Kit with `db:push` for schema migrations
- **Bot**: Discord.js client that responds to mentions using OpenAI API
- **API**: RESTful endpoints under `/api/`
- **Build**: esbuild bundles server code for production, Vite builds client

### API Routes
- `GET /api/messages` — Fetch all messages ordered by date descending
- `POST /api/messages` — Send a message to Discord webhook, store result in database

### Database Schema (shared/schema.ts)
Single table `messages`:
- `id` — serial primary key
- `content` — text, the message content
- `sent_at` — timestamp, defaults to now
- `success` — boolean, whether Discord webhook delivery succeeded
- `error` — text, error message if delivery failed

## Shared Code (shared/)
- `schema.ts` — Drizzle table definitions and Zod insert schemas
- `routes.ts` — API route manifest with paths, methods, and Zod response types (used by both client and server)

## Legacy Code (index.js)
There's an older `index.js` file at the root with a CommonJS-based Discord bot implementation. The active server code is in `server/` using ESM/TypeScript. The `index.js` file appears to be the original bot before the dashboard was added.

## Development vs Production
- **Dev**: `tsx server/index.ts` runs the server, Vite dev server handles frontend with HMR
- **Build**: Vite builds client to `dist/public`, esbuild bundles server to `dist/index.cjs`
- **Production**: `node dist/index.cjs` serves both API and static files

# External Dependencies

## Required Environment Variables
- `DATABASE_URL` — PostgreSQL connection string (required)
- `DISCORD_TOKEN` or `TOKEN` — Discord bot token (optional, bot won't start without it)
- `DISCORD_WEBHOOK_URL` — Discord webhook URL for sending messages from the dashboard (required for message sending)
- `OPENAI_API_KEY` — OpenAI API key for GPT-4o responses (required for AI bot responses)

## Third-Party Services
- **PostgreSQL** — Primary data store via Drizzle ORM
- **Discord API** — Bot connectivity via discord.js and webhook message delivery via fetch
- **OpenAI API** — GPT-4o model for AI-powered bot responses when mentioned in Discord

## Key npm Dependencies
- `discord.js` — Discord bot framework
- `openai` — OpenAI API client
- `drizzle-orm` + `drizzle-kit` — Database ORM and migration tool
- `express` — HTTP server
- `pg` — PostgreSQL client
- `zod` + `drizzle-zod` — Schema validation
- `@tanstack/react-query` — Client-side data fetching
- `framer-motion` — Animations
- `wouter` — Client-side routing
- Full shadcn/ui component library (Radix UI primitives)