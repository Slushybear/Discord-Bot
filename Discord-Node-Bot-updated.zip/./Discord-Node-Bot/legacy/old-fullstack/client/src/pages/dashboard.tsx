import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Send, Loader2, Sparkles, AlertCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useMessages, useSendMessage } from "@/hooks/use-messages";
import { Layout } from "@/components/layout";
import { MessageCard } from "@/components/message-card";
import { insertMessageSchema } from "@shared/schema";

// Schema for the form
const formSchema = insertMessageSchema;
type FormValues = z.infer<typeof formSchema>;

export default function Dashboard() {
  const { toast } = useToast();
  const { data: messages, isLoading: isLoadingMessages, isError } = useMessages();
  const { mutate: sendMessage, isPending: isSending } = useSendMessage();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      content: "",
    },
  });

  const onSubmit = (data: FormValues) => {
    sendMessage(data, {
      onSuccess: () => {
        toast({
          title: "Message Sent",
          description: "Your message has been delivered to Discord.",
          className: "bg-green-600 border-green-700 text-white",
        });
        form.reset();
      },
      onError: (error) => {
        toast({
          variant: "destructive",
          title: "Failed to Send",
          description: error.message,
        });
      },
    });
  };

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 h-full">
        {/* Left Column: Form */}
        <div className="lg:col-span-1">
          <div className="bg-card rounded-xl p-6 shadow-lg border border-white/5 sticky top-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-primary/20 rounded-lg text-primary">
                <Send size={20} />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Send Message</h2>
                <p className="text-xs text-muted-foreground">Post to #general via webhook</p>
              </div>
            </div>

            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-muted-foreground uppercase tracking-wider">
                  Message Content
                </label>
                <div className="relative">
                  <textarea
                    {...form.register("content")}
                    disabled={isSending}
                    placeholder="Type your announcement here..."
                    className="w-full min-h-[160px] p-4 rounded-lg bg-input/50 border border-black/20 text-white placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary focus:bg-black/20 transition-all resize-none font-sans text-sm"
                  />
                  {form.formState.errors.content && (
                    <span className="text-red-400 text-xs mt-1 block">
                      {form.formState.errors.content.message}
                    </span>
                  )}
                </div>
              </div>

              <button
                type="submit"
                disabled={isSending || !form.formState.isValid}
                className="w-full py-3 px-4 bg-primary hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold rounded-md transition-all duration-200 flex items-center justify-center gap-2 shadow-lg shadow-primary/20 hover:shadow-primary/40 hover:-translate-y-0.5 active:translate-y-0 active:shadow-md"
              >
                {isSending ? (
                  <>
                    <Loader2 className="animate-spin" size={18} />
                    Sending...
                  </>
                ) : (
                  <>
                    <Sparkles size={18} />
                    Send to Discord
                  </>
                )}
              </button>
              
              <p className="text-[10px] text-center text-muted-foreground mt-4">
                Messages are sent immediately via the configured webhook URL.
              </p>
            </form>
          </div>
        </div>

        {/* Right Column: History */}
        <div className="lg:col-span-2 flex flex-col h-full min-h-[500px]">
          <div className="bg-card rounded-xl shadow-lg border border-white/5 flex flex-col flex-1 overflow-hidden">
            <div className="p-4 border-b border-black/10 bg-black/10 flex items-center justify-between">
              <h3 className="font-bold text-muted-foreground uppercase text-xs tracking-wider flex items-center gap-2">
                <Clock size={14} />
                Message History
              </h3>
              <div className="text-xs text-muted-foreground">
                {messages?.length || 0} messages sent
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-2 space-y-2 custom-scrollbar">
              {isLoadingMessages ? (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground gap-4">
                  <Loader2 className="animate-spin text-primary" size={40} />
                  <p className="text-sm font-medium">Loading logs...</p>
                </div>
              ) : isError ? (
                <div className="h-full flex flex-col items-center justify-center text-red-400 gap-4">
                  <AlertCircle size={40} />
                  <p className="text-sm font-medium">Failed to load message history</p>
                </div>
              ) : messages && messages.length > 0 ? (
                [...messages].reverse().map((msg, idx) => (
                  <MessageCard
                    key={msg.id}
                    index={idx}
                    {...msg}
                  />
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-muted-foreground gap-4 opacity-50">
                  <div className="w-16 h-16 rounded-full bg-black/20 flex items-center justify-center">
                    <Send size={24} />
                  </div>
                  <p className="text-sm">No messages sent yet</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
