import { format } from "date-fns";
import { CheckCircle2, XCircle, Clock } from "lucide-react";
import { motion } from "framer-motion";

interface MessageCardProps {
  content: string;
  sentAt: string | null;
  success: boolean | null;
  error: string | null;
  id: number;
  index: number;
}

export function MessageCard({ content, sentAt, success, error, index }: MessageCardProps) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      className="group relative flex items-start gap-4 p-4 hover:bg-black/5 rounded-lg transition-colors border-l-2 border-transparent hover:border-primary/50"
    >
      <div className="mt-1 shrink-0">
        <div className={`
          w-10 h-10 rounded-full flex items-center justify-center shadow-lg
          ${success 
            ? "bg-green-500/20 text-green-400" 
            : "bg-red-500/20 text-red-400"}
        `}>
          {success ? <CheckCircle2 size={20} /> : <XCircle size={20} />}
        </div>
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2 mb-1">
          <span className="font-semibold text-white group-hover:underline cursor-pointer">
            System Bot
          </span>
          <span className="px-1.5 py-0.5 rounded-[4px] bg-primary text-[10px] font-bold text-white uppercase tracking-wide">
            BOT
          </span>
          <span className="text-xs text-muted-foreground ml-1 flex items-center gap-1">
            {sentAt ? format(new Date(sentAt), "MM/dd/yyyy h:mm aa") : "Sending..."}
          </span>
        </div>
        
        <p className={`text-sm md:text-base leading-relaxed break-words whitespace-pre-wrap ${success ? 'text-gray-300' : 'text-red-300/90'}`}>
          {content}
        </p>

        {error && (
          <div className="mt-2 p-2 rounded bg-red-500/10 border border-red-500/20 text-red-400 text-xs font-mono">
            Error: {error}
          </div>
        )}
      </div>
    </motion.div>
  );
}
