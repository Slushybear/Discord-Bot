# Discord Node Bot

Single runtime path:

- Entry file: `index.cjs`
- Start command: `npm start`

## Setup

1. Copy `.env.example` to `.env` (already done in this repo).
2. Fill in:
   - `DISCORD_TOKEN`
   - `OPENAI_API_KEY` (optional, but needed for moderation checks)
   - `MOD_LOG_CHANNEL_ID` (optional fallback if `config.json` `modLogChannelId` is empty)
   - `EVIDENCE_MIRROR_CHANNEL_ID` (optional fallback if `config.json` `evidenceMirrorChannelId` is empty)
   - `MOD_DECISION_DM_ENABLED` (optional, default `true`: DM suggested moderation action + reason)
   - `DISCORD_CLIENT_ID` (optional, for dashboard OAuth)
   - `DISCORD_CLIENT_SECRET` (optional, for dashboard OAuth)
   - `DISCORD_REDIRECT_URI` (optional, for dashboard OAuth callback)
3. Run:
   - `npm install`
   - `npm start`

## Replit Quick Deploy

1. Create a Replit Node.js repl and upload this folder.
2. Add Secrets:
   - `DISCORD_TOKEN`
   - `OPENAI_API_KEY`
   - `PORT` = `3000`
   - Optional tuning:
     - `MODERATION_CONCURRENCY` (default `1`)
     - `MODERATION_QUEUE_MAX` (default `500`)
     - `MODERATION_OVERLOAD_MODE` (`fail_open` recommended, or `fail_closed`)
     - `QUEUE_OVERLOAD_ALERT_COOLDOWN_MS` (default `300000`)
     - `OPENAI_MAX_RETRIES` (default `3`)
     - `OPENAI_RETRY_BASE_MS` (default `800`)
     - `DAILY_HEALTH_REPORT_ENABLED` (`true`/`false`, default `true`)
     - `DAILY_HEALTH_REPORT_INTERVAL_MS` (default `86400000` = 24h)
     - `WEEKLY_WARNING_RESET_ENABLED` (`true`/`false`, default `true`)
     - `WEEKLY_WARNING_RESET_INTERVAL_MS` (default `604800000` = 7d)
     - `WEEKLY_WARNING_RESET_CHECK_MS` (default `3600000` = 1h)
3. Run command: `npm install && npm start`
4. Optional OAuth hardening (recommended):
   - Create Discord OAuth app redirect URI:
     - `https://YOUR-REPL-NAME.YOUR-USERNAME.repl.co/oauth/callback`
   - Set Replit secrets:
     - `DISCORD_CLIENT_ID`
     - `DISCORD_CLIENT_SECRET`
     - `DISCORD_REDIRECT_URI`
   - In dashboard, set `dashboardAuth.enabled` to true and save role/user allowlists.

## Keep It Running 24/7

- Start under PM2: `npm run pm2:start`
- Restart bot: `npm run pm2:restart`
- View logs: `npm run pm2:logs`
- Save current PM2 process list: `npm run pm2:save`

PM2 startup is installed on this machine, so the bot is configured to relaunch after reboot.

## Notes

- Dashboard runs on `PORT` from `.env` (default `3000`).
- Health endpoint: `GET /health` (JSON uptime, readiness, counters).
- Dashboard API health endpoint: `GET /api/health`.
- Queue overload behavior:
  - `fail_open` (recommended): allow message when queue is full, log incident, send health alert.
  - `fail_closed`: block message when queue is full, log incident, send health alert.
- OpenAI moderation retries on `429` with exponential backoff.
- NSFW attachment signal detection is supported (keyword/file-name/content-type heuristic for images/gifs/files).
- Repeated harassment detection is supported (AI harassment categories + mention/keyword repetition threshold).
- Adaptive mode dynamically adjusts warning pressure and anti-raid strictness from recent incident volume.
- Contextual warnings are category-specific and escalate on repeated same-category abuse.
- Enforcement is timeout-only (no kick/ban), with durations clamped to 60s-10m by harshness.
- Warnings and incidents are persisted in `bot.db` (SQLite).
- Evidence snapshots are persisted in SQLite `evidence` table for moderated/deleted messages.
- Optional evidence mirror channel posts private copies of moderated content + attachment URLs.
- Decision DMs can send suggested action + action reason to `logUserId`.
- Daily health snapshot DM is sent to `logUserId` when enabled.
- Weekly warning reset can run automatically when enabled.
- Dashboard now uses Discord OAuth login (`/login` -> `/oauth/callback`).
- Anti-raid controls:
  - Slash command: `/raidmode` (`on`, `off`, `status`)
  - Dashboard toggle in the Anti-Raid card
- Extra slash commands:
  - `/warnings`
  - `/health`
  - `/modtest`
  - `/shadow` (`on/off/status`, with optional `minutes` when turning on)
- Incident log and false-positive controls are available in the dashboard UI.
- Timeout reliability checks now report explicit failure reasons (missing permission, role hierarchy, owner/admin).
- Shadow mode disables enforcement actions (delete/warn/timeout) while still logging incidents and sending suggested-action DMs.
- Tune `config.json`:
  - `contentSafety.nsfwKeywords` / `contentSafety.nsfwBlockInSfwChannels`
  - `harassment.repeatWindowMs` / `harassment.repeatThreshold` / `harassment.keywordPatterns`
  - `adaptive.windowMs` / `adaptive.highThreshold` / `adaptive.warningLimitHighOffset`
  - `timeoutProfile.lowMs` / `timeoutProfile.mediumMs` / `timeoutProfile.highMs` (60,000 to 600,000 ms)
- Old fullstack app files were moved to `legacy/old-fullstack/` to avoid confusion.
